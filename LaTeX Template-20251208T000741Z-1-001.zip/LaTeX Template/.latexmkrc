$latex='uplatex %O -kanji=utf8 -no-guess-input-enc -synctex=1 -interaction=nonstopmode -file-line-error %S';
$bibtex='upbibtex %O %B';
$biber='biber %O --bblencoding=utf8 -u -U --output_safechars %B';
$makeindex='upmendex %O -o %D %S';
$dvipdf='dvipdfmx %O -o %D %S';
-pdfdvi;